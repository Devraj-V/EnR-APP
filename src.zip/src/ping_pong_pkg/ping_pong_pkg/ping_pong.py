#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose
from geometry_msgs.msg import Twist
from turtlesim.srv import Spawn, TeleportAbsolute
import math
import random


class PingPong(Node):
    def __init__(self):
        super().__init__('ping_pong')
#Paddle(turtle1)
        self.p_pub=self.create_publisher(Twist,'/turtle1/cmd_vel',10)
        self.create_subscription(Pose,'/turtle1/pose',self.p_cb,10)
        self.p_pose=None
#Ball(turtle2)
        self.x=5.5
        self.y=5.5
        angle=random.uniform(0,2*math.pi)
        self.speed=0.05
        self.vx=self.speed*math.cos(angle)
        self.vy=self.speed*math.sin(angle)
#Paddle line
        self.p_line=1.1
#Hit line
        self.line=self.p_line + 0.5

        self.timer = self.create_timer(0.02, self.loop)
        self.spawn_b()
        self.set_p_position()   


# Spawn ball(turtle2)
    def spawn_b(self):
        client=self.create_client(Spawn,'/spawn')
        while not client.wait_for_service(timeout_sec=1.0):
            pass
        req=Spawn.Request()
        req.x=self.x
        req.y=self.y
        req.theta=0.0
        req.name='turtle2'
        future=client.call_async(req)
        rclpy.spin_until_future_complete(self,future)
 
    def set_p_position(self):
        client=self.create_client(TeleportAbsolute,'/turtle1/teleport_absolute')
        while not client.wait_for_service(timeout_sec=1.0):
            pass
        req=TeleportAbsolute.Request()
        req.x=5.5
        req.y=self.p_line   
        req.theta= 0.0
        future=client.call_async(req)
        rclpy.spin_until_future_complete(self, future)

    def p_cb(self,msg):
        self.p_pose=msg
        
#Using teleport function to move the ball every frame
    def teleport_b(self):
        client=self.create_client(TeleportAbsolute,'/turtle2/teleport_absolute')
        if not client.wait_for_service(timeout_sec=0.2):
            return
        req=TeleportAbsolute.Request()
        req.x=self.x
        req.y=self.y
        req.theta=math.atan2(self.vy,self.vx)
        client.call_async(req)

#Game loop
    def loop(self):
        p_cmd=Twist()
        dis=self.x - self.p_pose.x
#Speed of paddle is proprtional to the difference in x coordinates bw ball and paddle
        p_cmd.linear.x=max(min(5.0*dis,3.5),-3.5)
        p_cmd.angular.z=0.0
        self.p_pub.publish(p_cmd)
        prev_x=self.x
        prev_y=self.y
        self.x+=self.vx
        self.y+=self.vy

#Wall collision logic
        if prev_x>1.0 and self.x<=1.0:
            self.x=1.0
            self.vx*=-1
        if prev_x<10.5 and self.x>=10.5:
            self.x=10.5
            self.vx*=-1
        if prev_y<10.5 and self.y>=10.5:
            self.y=10.5
            self.vy*=-1
        if prev_y>1.0 and self.y<=1.0:
            self.y=1.0
            self.vy*=-1
#There is no actual collision happening here.
#If the ball reaches a point just above the paddle, it bounces.
        if (self.vy < 0 and prev_y > self.line and self.y <= self.line):
            self.y=self.line
            self.vy*=-1

        self.teleport_b()

def main(args=None):
    rclpy.init(args=args)
    node = PingPong()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

